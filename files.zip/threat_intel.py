import requests, os

ABUSEIPDB_KEY = os.environ.get("ABUSEIPDB_KEY")

# ── Country code → full country name ─────────────────────────────────────────
COUNTRY_NAMES = {
    "AF":"Afghanistan","AL":"Albania","DZ":"Algeria","AR":"Argentina",
    "AM":"Armenia","AU":"Australia","AT":"Austria","AZ":"Azerbaijan",
    "BH":"Bahrain","BD":"Bangladesh","BY":"Belarus","BE":"Belgium",
    "BR":"Brazil","BG":"Bulgaria","CA":"Canada","CL":"Chile","CN":"China",
    "CO":"Colombia","HR":"Croatia","CZ":"Czech Republic","DK":"Denmark",
    "EG":"Egypt","EE":"Estonia","ET":"Ethiopia","FI":"Finland","FR":"France",
    "GE":"Georgia","DE":"Germany","GH":"Ghana","GR":"Greece","GT":"Guatemala",
    "HK":"Hong Kong","HU":"Hungary","IN":"India","ID":"Indonesia","IR":"Iran",
    "IQ":"Iraq","IE":"Ireland","IL":"Israel","IT":"Italy","JP":"Japan",
    "JO":"Jordan","KZ":"Kazakhstan","KE":"Kenya","KP":"North Korea",
    "KR":"South Korea","KW":"Kuwait","LV":"Latvia","LB":"Lebanon","LT":"Lithuania",
    "MY":"Malaysia","MX":"Mexico","MA":"Morocco","MM":"Myanmar","NL":"Netherlands",
    "NZ":"New Zealand","NG":"Nigeria","NO":"Norway","PK":"Pakistan","PE":"Peru",
    "PH":"Philippines","PL":"Poland","PT":"Portugal","QA":"Qatar","RO":"Romania",
    "RU":"Russia","SA":"Saudi Arabia","SG":"Singapore","ZA":"South Africa",
    "ES":"Spain","SE":"Sweden","CH":"Switzerland","SY":"Syria","TW":"Taiwan",
    "TH":"Thailand","TR":"Turkey","UA":"Ukraine","AE":"UAE","GB":"United Kingdom",
    "US":"United States","UZ":"Uzbekistan","VN":"Vietnam","YE":"Yemen",
    "ZW":"Zimbabwe","NP":"Nepal","LK":"Sri Lanka","RS":"Serbia","SK":"Slovakia",
    "SI":"Slovenia","TN":"Tunisia","LY":"Libya","OM":"Oman","EC":"Ecuador",
    "DO":"Dominican Republic","CU":"Cuba","VE":"Venezuela","BO":"Bolivia",
    "PY":"Paraguay","UY":"Uruguay","CR":"Costa Rica","PA":"Panama",
    "HN":"Honduras","SV":"El Salvador","NI":"Nicaragua","JM":"Jamaica",
    "IS":"Iceland","LU":"Luxembourg","CY":"Cyprus","MT":"Malta","MD":"Moldova",
    "BA":"Bosnia","MN":"Mongolia","KG":"Kyrgyzstan","TJ":"Tajikistan",
    "TM":"Turkmenistan","MK":"North Macedonia",
}

# ── Cache to avoid repeated lookups for same IP ───────────────────────────────
_geo_cache: dict = {}

# Known dangerous ports
THREAT_PORTS = {
    22: "SSH Brute Force", 23: "Telnet", 3389: "RDP Attack",
    445: "SMB/WannaCry", 135: "RPC Exploit", 1433: "MSSQL Attack",
    3306: "MySQL Attack", 6379: "Redis Attack", 9200: "Elasticsearch",
    4444: "Metasploit", 8080: "Alt HTTP Scan", 53: "DNS Abuse"
}

def is_private_ip(ip: str) -> bool:
    return ip.startswith((
        "192.168.", "10.", "172.16.", "172.17.", "172.18.", "172.19.",
        "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
        "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.",
        "127.", "0.", "224.", "239.", "169.254."
    ))

def _get_country_free(ip: str) -> str:
    """Look up country using free ip-api.com (no API key needed, 45 req/min)."""
    if ip in _geo_cache:
        return _geo_cache[ip]
    try:
        r = requests.get(
            f"http://ip-api.com/json/{ip}?fields=status,countryCode,country",
            timeout=2
        )
        data = r.json()
        if data.get("status") == "success":
            code = data.get("countryCode", "")
            name = COUNTRY_NAMES.get(code, data.get("country", code))
            _geo_cache[ip] = name
            return name
    except:
        pass
    _geo_cache[ip] = "Unknown"
    return "Unknown"

def check_port_threat(port: int) -> dict:
    if port in THREAT_PORTS:
        return {"is_threat": True, "reason": THREAT_PORTS[port]}
    return {"is_threat": False, "reason": ""}

def get_risk_level(score: float) -> str:
    if score >= 80:   return "CRITICAL"
    elif score >= 50: return "HIGH"
    elif score >= 25: return "MEDIUM"
    elif score >= 10: return "LOW"
    else:             return "SAFE"

def check_ip_reputation(ip: str) -> dict:
    # For private/local IPs
    if is_private_ip(ip):
        return {"is_malicious": False, "risk_score": 0,
                "reason": "", "country": "Local Network", "isp": "Private"}

    # If AbuseIPDB key is set, use it
    if ABUSEIPDB_KEY:
        try:
            r = requests.get(
                "https://api.abuseipdb.com/api/v2/check",
                headers={"Key": ABUSEIPDB_KEY, "Accept": "application/json"},
                params={"ipAddress": ip, "maxAgeInDays": 90},
                timeout=3
            )
            d = r.json()["data"]
            score = d["abuseConfidenceScore"]
            code = d.get("countryCode", "")
            country = COUNTRY_NAMES.get(code, code) if code else _get_country_free(ip)
            return {
                "is_malicious": score >= 50,
                "risk_score":   score,
                "reason":       f"AbuseIPDB: {d['totalReports']} reports",
                "country":      country,
                "isp":          d.get("isp", "Unknown")
            }
        except:
            pass

    # No API key — use free geo-IP lookup
    country = _get_country_free(ip)
    return {"is_malicious": False, "risk_score": 0,
            "reason": "", "country": country, "isp": "Unknown"}
